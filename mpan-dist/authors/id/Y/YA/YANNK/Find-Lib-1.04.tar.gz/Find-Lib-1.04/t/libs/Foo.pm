package Foo;

use Test::More;
ok 1, __PACKAGE__ . " loaded";
1;
