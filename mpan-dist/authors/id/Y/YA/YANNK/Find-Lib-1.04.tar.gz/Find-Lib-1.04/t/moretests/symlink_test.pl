#!perl
## this is not a test in itself, don't execute
## this is a script that is executed by a test
use Find::Lib '../t/mylib';
use MyLibNoTest;
exit 0;
